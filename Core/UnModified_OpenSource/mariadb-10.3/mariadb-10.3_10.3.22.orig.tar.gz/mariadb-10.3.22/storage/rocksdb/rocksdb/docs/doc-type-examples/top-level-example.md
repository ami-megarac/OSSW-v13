---
layout: top-level
title: Support Example
id: top-level-example
category: top-level
---

This is a static page disconnected from the blog or docs collections that can be added at a top-level (i.e., the same level as `index.md`).
